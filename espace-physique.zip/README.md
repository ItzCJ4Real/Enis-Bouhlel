# Espace Physique — plateforme pédagogique

Application Next.js 14 + Supabase : bibliothèque publique, recherche et filtres, prévisualisation/téléchargement via URL signée, connexion professeur, tableau de bord, modification des métadonnées et gestion des fichiers.

## Prérequis
- Node.js 20+
- Un projet Supabase

## Installation locale
1. `npm install`
2. Copiez `.env.example` vers `.env.local`.
3. Renseignez l'URL du projet Supabase et la clé `anon` (Project Settings > API).
4. Dans Supabase > SQL Editor, exécutez intégralement `supabase/schema.sql`.
5. Dans Supabase > Authentication > Users, créez le compte professeur (email + mot de passe).
6. Copiez l'UUID de cet utilisateur puis exécutez :
   `insert into public.admin_users(user_id) values ('UUID-DU-PROFESSEUR');`
7. `npm run dev`, puis ouvrez http://localhost:3000.

## Administration
- Accès : `/connexion`, puis `/admin`.
- Les opérations sensibles sont protégées par Supabase Auth et les politiques RLS.
- Le stockage `documents` est privé. Les documents publiés sont consultables via des URL signées courtes ; les fichiers non publiés restent réservés à l'administrateur.
- Taille maximale : 25 Mo. Formats : PDF, DOC, DOCX.
- Les suppressions demandent une confirmation.

## Déploiement (Vercel)
1. Poussez le projet dans un dépôt Git.
2. Importez-le dans Vercel.
3. Ajoutez `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY` dans les variables d'environnement Vercel.
4. Déployez. Les migrations SQL et la création du compte administrateur restent à effectuer dans Supabase.

## Personnalisation
- Remplacez `PHYSIQUE.` dans `src/components/Header.tsx` et `Footer.tsx` par le nom du professeur.
- Modifiez l'adresse `professeur@exemple.tn` dans `Footer.tsx`.
- Les niveaux et chapitres sont saisis librement dans le formulaire d'administration.

## Sécurité et limites à connaître
- Ne placez jamais la clé `service_role` dans une variable `NEXT_PUBLIC_*` ni dans le navigateur.
- L'ajout d'un administrateur se fait volontairement depuis le SQL Editor par le propriétaire du projet.
- Avant une mise en production à grande échelle, activez la confirmation d'e-mail, configurez les règles de mot de passe et le SMTP personnalisé dans Supabase Auth, ajoutez une politique de sauvegarde et un contrôle antivirus des fichiers.
- Le nom du professeur et les coordonnées sont des valeurs temporaires à remplacer.
