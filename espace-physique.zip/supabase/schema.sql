-- À exécuter dans SQL Editor de Supabase.
create extension if not exists pgcrypto;
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text not null check (category in ('cours','series','devoirs','examens')),
  level text,
  chapter text,
  file_name text not null,
  file_path text not null unique,
  file_type text not null,
  published_at date not null default current_date,
  is_published boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
alter table public.resources enable row level security;
create policy "Admin list own role" on public.admin_users for select to authenticated using (user_id=auth.uid());
create policy "Public read published resources" on public.resources for select to anon,authenticated using (is_published=true);
create policy "Admins read all resources" on public.resources for select to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
create policy "Admins insert resources" on public.resources for insert to authenticated with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
create policy "Admins update resources" on public.resources for update to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid())) with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
create policy "Admins delete resources" on public.resources for delete to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('documents','documents',false,26214400,array['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
on conflict (id) do nothing;
create policy "Public can read published document files" on storage.objects for select to anon,authenticated using (
 bucket_id='documents' and exists(select 1 from public.resources r where r.file_path=name and r.is_published=true)
);
create policy "Admins can read all document files" on storage.objects for select to authenticated using (
 bucket_id='documents' and exists(select 1 from public.admin_users a where a.user_id=auth.uid())
);
create policy "Admins can upload document files" on storage.objects for insert to authenticated with check (
 bucket_id='documents' and exists(select 1 from public.admin_users a where a.user_id=auth.uid())
);
create policy "Admins can delete document files" on storage.objects for delete to authenticated using (
 bucket_id='documents' and exists(select 1 from public.admin_users a where a.user_id=auth.uid())
);
-- Après avoir créé l'utilisateur dans Authentication > Users, ajoutez son UUID :
-- insert into public.admin_users(user_id) values ('UUID-DE-L-UTILISATEUR');
