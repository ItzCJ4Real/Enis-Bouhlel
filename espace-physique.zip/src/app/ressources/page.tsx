import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {createClient} from "@/lib/supabase/server";
import {Resource,categories} from "@/lib/types";
import ResourceFilters from "./ResourceFilters";
export const dynamic="force-dynamic";
export default async function Resources({searchParams}:{searchParams:{categorie?:string}}){
 const supabase=await createClient();
 let query=supabase.from("resources").select("*").eq("is_published",true).order("published_at",{ascending:false});
 if(searchParams.categorie && categories.some(c=>c.key===searchParams.categorie)) query=query.eq("category",searchParams.categorie);
 const {data,error}=await query;
 const resources=await Promise.all(((data||[]) as Resource[]).map(async item=>{const {data:link}=await supabase.storage.from("documents").createSignedUrl(item.file_path,3600);return {...item,signedUrl:link?.signedUrl||null};}));
 return <><Header/><main className="container page"><div className="eyebrow">Bibliothèque</div><h1>Ressources pédagogiques</h1><p className="muted">Recherchez et consultez les supports disponibles.</p>{error?<div className="notice">Impossible de charger les ressources. Réessayez ultérieurement.</div>:<ResourceFilters items={resources}/>}</main><Footer/></>
}