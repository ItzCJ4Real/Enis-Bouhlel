export type Category = "cours" | "series" | "devoirs" | "examens";
export type Resource = {
  id: string; title: string; description: string | null; category: Category;
  level: string | null; chapter: string | null; file_name: string;
  file_path: string; file_type: string; published_at: string; is_published: boolean;
};
export const categories: {key:Category; label:string; description:string}[] = [
  {key:"cours",label:"Cours",description:"Les notions essentielles, chapitre par chapitre."},
  {key:"series",label:"Séries d’exercices",description:"Entraînez-vous avec des exercices progressifs."},
  {key:"devoirs",label:"Devoirs",description:"Devoirs surveillés, synthèses et corrigés."},
  {key:"examens",label:"Examens",description:"Sujets types et examens des années précédentes."}
];