import type {Resource} from "@/lib/types";
export default function ResourceCard({item,url}:{item:Resource;url:string|null}){
 const date=new Date(item.published_at).toLocaleDateString("fr-FR");
 return <article className="resource"><div className="tag">{item.category} · {item.file_type.toUpperCase()}</div><h3>{item.title}</h3><p>{item.description||"Ressource pédagogique à consulter."}</p><div className="meta"><span>{item.level||"Tous niveaux"}</span>{item.chapter&&<span>{item.chapter}</span>}<span>{date}</span></div><div className="resource-actions">{url&&<><a className="btn secondary" href={url} target="_blank" rel="noreferrer">Consulter</a><a className="btn" href={url} download={item.file_name}>Télécharger</a></>}</div></article>
}