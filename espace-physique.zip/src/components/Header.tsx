"use client";
import Link from "next/link";
import {useState} from "react";
export default function Header(){
 const [open,setOpen]=useState(false);
 const links=[["Accueil","/"],["Cours","/ressources?categorie=cours"],["Séries d’exercices","/ressources?categorie=series"],["Devoirs","/ressources?categorie=devoirs"],["Examens","/ressources?categorie=examens"],["À propos","/#apropos"],["Contact","/#contact"]];
 return <header className="header"><div className="container nav"><Link href="/" className="brand">PHYSIQUE.<small>ESPACE PÉDAGOGIQUE</small></Link><button className="mobile-toggle" onClick={()=>setOpen(!open)} aria-label="Ouvrir le menu">☰</button><nav className={`links ${open?"open":""}`}>{links.map(([label,url])=><Link key={label} href={url} onClick={()=>setOpen(false)}>{label}</Link>)}</nav></div></header>
}